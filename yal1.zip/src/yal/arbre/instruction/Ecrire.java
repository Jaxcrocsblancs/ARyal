package yal.arbre.instruction;

import yal.arbre.ArbreAbstrait;

public abstract class Ecrire extends ArbreAbstrait
{
	protected Ecrire(int n)
	{
		super(n);
	}
}
